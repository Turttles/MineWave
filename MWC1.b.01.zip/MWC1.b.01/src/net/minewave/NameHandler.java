package net.minewave;

public class NameHandler {

}
